/**
 * Honey House Google Sheets backend
 * Spreadsheet tabs: Products, Orders, Order_Items, Shipping
 * Set Script Properties: SPREADSHEET_ID and API_SECRET
 */
const TABS={orders:"Orders",items:"Order_Items",shipping:"Shipping"};
function doPost(e){
 try{
  const p=JSON.parse(e.postData.contents||"{}");
  if(p.action==="createOrder")return output(createOrder(p.data||{}));
  if(p.secret!==PropertiesService.getScriptProperties().getProperty("API_SECRET"))return output({ok:false,error:"Unauthorized"});
  if(p.action==="list")return output(listOrders());
  if(p.action==="get")return output(getOrder(p.data.orderId));
  if(p.action==="status")return output(updateStatus(p.data.orderId,p.data.status));
  return output({ok:false,error:"Unknown action"});
 }catch(err){return output({ok:false,error:String(err)})}
}
function output(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON)}
function db(){const id=PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");if(!id)throw new Error("Missing SPREADSHEET_ID");return SpreadsheetApp.openById(id)}
function sheet(name,headers){let s=db().getSheetByName(name);if(!s)s=db().insertSheet(name);if(s.getLastRow()===0)s.appendRow(headers);return s}
function setupSheets(){
 sheet(TABS.orders,["Order ID","Created At","Customer Name","Phone","Email","Address","Subdistrict","District","Province","Postcode","Note","Total","Status"]);
 sheet(TABS.items,["Order ID","SKU","Product Name","Quantity","Unit Price","Line Total"]);
 sheet(TABS.shipping,["Order ID","Recipient","Phone","Address","Subdistrict","District","Province","Postcode","Tracking Number","Shipping Status"]);
 sheet("Products",["SKU","Product Name","Unit Price","Stock","Image Path"]);
}
function createOrder(d){
 const required=["customerName","phone","address","subdistrict","district","province","postcode"];
 required.forEach(k=>{if(!d[k]||String(d[k]).trim()==="")throw new Error("กรุณากรอกข้อมูลให้ครบ: "+k)});
 if(!/^\d{5}$/.test(String(d.postcode)))throw new Error("รหัสไปรษณีย์ต้องมี 5 หลัก");
 if(!Array.isArray(d.items)||!d.items.length)throw new Error("ไม่มีสินค้าในคำสั่งซื้อ");
 const catalog={"HH-01":{name:"น้ำผึ้งดอกลำไย",price:250},"HH-02":{name:"น้ำผึ้งป่า",price:300}};
 let total=0;const clean=d.items.map(i=>{const p=catalog[i.sku];const q=Number(i.quantity);if(!p||!Number.isInteger(q)||q<1||q>99)throw new Error("รายการสินค้าไม่ถูกต้อง");total+=p.price*q;return {sku:i.sku,name:p.name,quantity:q,price:p.price,line:p.price*q}});
 const id="HH"+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),"yyMMddHHmmss")+"-"+Math.floor(Math.random()*900+100);const now=new Date();
 sheet(TABS.orders,["Order ID","Created At","Customer Name","Phone","Email","Address","Subdistrict","District","Province","Postcode","Note","Total","Status"]).appendRow([id,now,d.customerName,d.phone,d.email||"",d.address,d.subdistrict,d.district,d.province,d.postcode,d.note||"",total,"รอดำเนินการ"]);
 const s=sheet(TABS.items,["Order ID","SKU","Product Name","Quantity","Unit Price","Line Total"]);clean.forEach(i=>s.appendRow([id,i.sku,i.name,i.quantity,i.price,i.line]));
 sheet(TABS.shipping,["Order ID","Recipient","Phone","Address","Subdistrict","District","Province","Postcode","Tracking Number","Shipping Status"]).appendRow([id,d.customerName,d.phone,d.address,d.subdistrict,d.district,d.province,d.postcode,"","รอดำเนินการ"]);
 return {ok:true,orderId:id,total:total};
}
function listOrders(){
 const s=sheet(TABS.orders,["Order ID","Created At","Customer Name","Phone","Email","Address","Subdistrict","District","Province","Postcode","Note","Total","Status"]);const v=s.getDataRange().getValues();const orders=[];
 for(let i=1;i<v.length;i++){const r=v[i];if(!r[0])continue;orders.push({orderId:String(r[0]),createdAt:r[1] instanceof Date?Utilities.formatDate(r[1],Session.getScriptTimeZone(),"yyyy-MM-dd HH:mm"):String(r[1]),customerName:r[2],phone:r[3],email:r[4],address:r[5],subdistrict:r[6],district:r[7],province:r[8],postcode:r[9],note:r[10],total:r[11],status:r[12],items:getItems(String(r[0]))})}
 orders.reverse();return {ok:true,orders};
}
function getItems(id){const s=sheet(TABS.items,["Order ID","SKU","Product Name","Quantity","Unit Price","Line Total"]);const v=s.getDataRange().getValues();return v.slice(1).filter(r=>String(r[0])===id).map(r=>({sku:r[1],name:r[2],quantity:r[3],unitPrice:r[4],lineTotal:r[5]}))}
function getOrder(id){const o=listOrders().orders.find(x=>x.orderId===String(id));if(!o)throw new Error("ไม่พบคำสั่งซื้อ");return {ok:true,order:o}}
function updateStatus(id,status){const allowed=["รอดำเนินการ","กำลังหยิบสินค้า","แพ็คแล้ว","จัดส่งแล้ว","ยกเลิก"];if(!allowed.includes(status))throw new Error("สถานะไม่ถูกต้อง");const s=sheet(TABS.orders,["Order ID","Created At","Customer Name","Phone","Email","Address","Subdistrict","District","Province","Postcode","Note","Total","Status"]);const v=s.getDataRange().getValues();for(let i=1;i<v.length;i++){if(String(v[i][0])===String(id)){s.getRange(i+1,13).setValue(status);const sh=sheet(TABS.shipping,["Order ID","Recipient","Phone","Address","Subdistrict","District","Province","Postcode","Tracking Number","Shipping Status"]);const sv=sh.getDataRange().getValues();for(let j=1;j<sv.length;j++)if(String(sv[j][0])===String(id))sh.getRange(j+1,10).setValue(status);return {ok:true}}}throw new Error("ไม่พบคำสั่งซื้อ")}
