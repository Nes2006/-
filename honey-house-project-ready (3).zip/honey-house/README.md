# Honey House — Nature-inspired honey shop

ร้านค้าออนไลน์ตัวอย่างพร้อมหน้าร้าน, Google Sheets order backend, หน้าผู้ดูแล, Picking & Packing checklist และใบจ่าหน้าพัสดุสำหรับพิมพ์

## โครงสร้าง
- `index.html` หน้าร้านและ checkout
- `admin.html` หน้าจัดการออเดอร์ (ต้องใช้รหัสผ่านผู้ดูแล)
- `api/order.js` และ `api/admin.js` Vercel Serverless Functions
- `apps-script/Code.gs` Google Sheets backend
- `images/` รูปภาพ SVG แยกโฟลเดอร์
- `js/`, `css/` ไฟล์หน้าบ้าน

## 1) เตรียม Google Sheets
1. สร้าง Google Spreadsheet ใหม่ ตั้งชื่อ `Honey House Orders`
2. เปิด Extensions > Apps Script แล้ววางโค้ดจาก `apps-script/Code.gs` ใน `Code.gs`
3. ใน Apps Script ไปที่ Project Settings > Script Properties เพิ่ม:
   - `SPREADSHEET_ID` = ID ของ Google Sheet (ข้อความระหว่าง `/d/` และ `/edit` ใน URL)
   - `API_SECRET` = สุ่มรหัสลับยาวอย่างน้อย 32 ตัวอักษร
4. เลือกฟังก์ชัน `setupSheets` แล้วกด Run และอนุญาตสิทธิ์ เพื่อสร้างชีต Products, Orders, Order_Items, Shipping
5. Deploy > New deployment > Web app
   - Execute as: Me
   - Who has access: Anyone
   - Deploy แล้วคัดลอก Web app URL ที่ลงท้าย `/exec`
   - หมายเหตุ: endpoint สาธารณะรับเฉพาะการสร้างออเดอร์; คำสั่ง admin ต้องมี secret ซึ่งส่งผ่าน Vercel serverless function

## 2) เตรียม GitHub
1. สร้าง repository ใหม่ เช่น `honey-house`
2. แตกไฟล์ ZIP นี้ แล้วอัปโหลดไฟล์และโฟลเดอร์ทั้งหมดเข้า repository (เก็บโฟลเดอร์ `images` แยกตามโจทย์)
3. Commit changes

## 3) Deploy บน Vercel
1. เข้าสู่ Vercel แล้วเลือก Add New > Project
2. Import Git Repository `honey-house`
3. Framework Preset เลือก Other; Build Command เว้นว่าง; Output Directory เป็น `.`; Install Command เว้นว่าง
4. Project Settings > Environment Variables เพิ่มค่าต่อไปนี้ทุก Environment ที่ใช้:
   - `APPS_SCRIPT_URL` = Google Apps Script Web App URL
   - `APPS_SCRIPT_SECRET` = ค่าเดียวกับ Script Property `API_SECRET`
   - `ADMIN_PASSWORD` = ตั้งรหัสผ่านผู้ดูแลที่คาดเดายาก
5. Deploy แล้วทดสอบ URL ที่ Vercel ให้มา

## 4) ทดสอบระบบ
1. เปิดหน้าเว็บ เลือกสินค้าอย่างน้อย 1 รายการ กรอกข้อมูลจัดส่ง และยืนยัน
2. ตรวจสอบว่าแถวใหม่ถูกเพิ่มใน `Orders`, `Order_Items`, `Shipping`
3. เปิด `/admin.html` เข้าด้วย `ADMIN_PASSWORD`
4. ใช้ Picking checklist ติ๊กสินค้า แล้วกด "ยืนยันแพ็คสินค้าแล้ว"
5. กด "พิมพ์ใบจ่าหน้า" แล้วกรอกที่อยู่และเบอร์โทรผู้ส่งจริงก่อนเปิดหน้าพิมพ์
6. ระบบจะไม่ยอมให้ยืนยันแพ็คจนกว่าจะติ๊ก Picking checklist ครบทุกรายการ

## 5) แก้ไขข้อมูลร้านก่อนเปิดจริง
- แก้ชื่อ/รายละเอียด/ราคา/รูปสินค้าใน `js/store.js` และราคา SKU ที่ตรวจสอบซ้ำใน `apps-script/Code.gs`
- แก้รูปสินค้าใน `images/`
- ใบจ่าหน้าจะถามที่อยู่และเบอร์โทรผู้ส่งทุกครั้งก่อนพิมพ์ เพื่อป้องกันการพิมพ์ข้อมูลผู้ส่งที่ยังไม่ได้ตั้งค่า
- เพิ่มค่าจัดส่ง/ช่องทางชำระเงินและนโยบายคืนสินค้าให้ชัดเจนก่อนเปิดขาย

## สถานะการเชื่อมต่อและข้อจำกัด
- Google Sheets ต้องสร้างและ Deploy Apps Script ด้วยบัญชี Google ของเจ้าของร้านตามขั้นตอนด้านบน; การเชื่อมต่อ Google Drive/Sheets อัตโนมัติไม่พร้อมใช้งานใน workspace นี้
- GitHub repository ต้องสร้างจากบัญชี GitHub ก่อน แล้วจึงอัปโหลดไฟล์ใน ZIP นี้; ไม่พบ repository ที่เข้าถึงได้ในบัญชีที่เชื่อมต่ออยู่
- Vercel ต้องเชื่อมบัญชีและ Import repository หลังจากอัปโหลด GitHub แล้ว

## ข้อจำกัดและความปลอดภัย
- ตัวอย่างนี้ยังไม่ตัดสต็อกอัตโนมัติ ไม่ได้เชื่อม API ขนส่งเพื่อซื้อเลข Tracking และไม่มี payment gateway; ใบจ่าหน้าเป็นแบบพิมพ์ข้อมูลผู้รับ/ผู้ส่ง ไม่ใช่ใบปะหน้าจากผู้ให้บริการขนส่ง
- Apps Script Web App แบบ Anyone จำเป็นสำหรับรับออเดอร์จากหน้าเว็บ; ควรเพิ่ม CAPTCHA/rate limiting และการตรวจจับคำสั่งซื้อซ้ำก่อนเปิดสาธารณะ
- ห้ามใส่ `API_SECRET` หรือ `ADMIN_PASSWORD` ลงใน JavaScript ฝั่ง browser หรือ GitHub
- เปลี่ยนรหัสลับทันทีหากเผลอเผยแพร่

## Local preview
ใช้ Vercel CLI หรือ static server; API endpoints จะทำงานเมื่อรันผ่าน Vercel environment เท่านั้น
