export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 const {APPS_SCRIPT_URL,ADMIN_PASSWORD,APPS_SCRIPT_SECRET}=process.env;
 if(!APPS_SCRIPT_URL||!ADMIN_PASSWORD||!APPS_SCRIPT_SECRET)return res.status(500).json({error:"ยังไม่ได้ตั้งค่า Environment Variables"});
 if(req.headers["x-admin-password"]!==ADMIN_PASSWORD)return res.status(401).json({error:"รหัสผ่านไม่ถูกต้อง"});
 try{const r=await fetch(APPS_SCRIPT_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:req.body.action,data:req.body,secret:APPS_SCRIPT_SECRET})});const d=await r.json();if(!r.ok||!d.ok)return res.status(400).json({error:d.error||"ดำเนินการไม่สำเร็จ"});return res.status(200).json(d)}catch(e){return res.status(500).json({error:"เชื่อมต่อ Google Sheets ไม่สำเร็จ"})}
}