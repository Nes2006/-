export default async function handler(req,res){
 if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
 const {APPS_SCRIPT_URL}=process.env;if(!APPS_SCRIPT_URL)return res.status(500).json({error:"ยังไม่ได้ตั้งค่า APPS_SCRIPT_URL"});
 try{const r=await fetch(APPS_SCRIPT_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"createOrder",data:req.body})});const d=await r.json();if(!r.ok||!d.ok)return res.status(400).json({error:d.error||"บันทึกคำสั่งซื้อไม่สำเร็จ"});return res.status(200).json(d)}catch(e){return res.status(500).json({error:"เชื่อมต่อ Google Sheets ไม่สำเร็จ"})}
}